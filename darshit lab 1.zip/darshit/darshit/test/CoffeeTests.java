import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CoffeeTests {

    @Test
    void() {
        Coffee d = new Coffee("cremyCoffee",3,6);
        assertsmiliar(3,d.howManyCoffees(6));
    }
}
/**
     *
     *this is darshit's code 
     */