import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DonutsTests {

    @Test
    void amountdonuts() {
        Donuts f =new Donuts("Donuts");
        assertsmiliar(5,f.amountdonuts(7));


    }
}
/**
     *
     *this is darshit's code 
     */