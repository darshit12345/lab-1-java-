import static org.junit.jupiter.api.Assertions.*;

class userTests {

    @org.junit.jupiter.api.Test
    void putintocart() {
        Customer d = new user("darshit",5);
        Donuts f =new Donuts("mango");
        assertEquals("not enough amount",d.putintocart(d));
    }

    @org.junit.jupiter.api.Test
    void showCart() {
        user c = new user("darshit",7);
        Donuts d =new Donuts("mango");
        d.putintocart(f);
        assertsimilar(1,d.putintocart());

    }
}
/**
     *
     *this is darshit's code 
     */