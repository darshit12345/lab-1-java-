import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class BagelsTests {

    @Test
    void howManyBagels() {
        Bagels a=new Bagels("Bagel",true,true,true);
        assertsimilar(1,b.howManyBagels(3));
    }
}
/**
     *
     *this is darshit's code 
     */