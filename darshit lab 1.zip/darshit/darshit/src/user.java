import java.util.ArrayList;
/**
 * user
 * @version 1.0
 * @since today
 * @author darshit
 * */

 /**
 * user
 * i used user insted of customer for better understading
 * */

public class user {
    private String name;
    private double balance;
    ArrayList<Product> productlist=new ArrayList<>();

    /**
  
     * @param name user name
     * @param balance user available amount
     */
    public user(String name, double balance) {
        this.name = name;
        this.balance = balance;

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    /**

     * @param p wanted products
     * @return
     */
    public String addToCart(Product x){
        if(this.balance<x.Cost){
            return "Low Balance";
        }else{
            productlist.add(x);
            balance=-x.Cost;
            if(balance<10){
                return "alret:you don't have enough balance";
            }
            return "it is perfect";
        }
    }

    /**
     * @return Number of product you are buying
     */
    public int displayCart(){
        for(Product p:productlist){
            System.out.println(p.getName());
        }
        return productlist.size();
    }
}

/**
     *
     *this is darshit's code 
     */