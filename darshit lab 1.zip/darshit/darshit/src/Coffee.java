/**
 * Coffee
 * @version 1.0
 * @since today
 * @author darshit
 * */
public class Coffee extends Product{
    private int numOfCream;
    private int numOfSugar;

    /**

     * @param name coffee name
     * @param numOfCream coffee amount wanted 
     * @param numOfSugar sugar amount wanted 
     */

    public Coffee(String name,int numOfCream,int numOfSugar) {

        super(name,3.70);
        this.numOfCream=numOfCream;
        this.numOfSugar=numOfSugar;
    }


    public int getNumOfCream() {
        return numOfCream;
    }

    public void setNumOfCream(int numOfCream) {
        this.numOfCream = numOfCream;
    }

    public int getNumOfSugar() {
        return numOfSugar;
    }

    public void setNumOfSugar(int numOfSugar) {
        this.numOfSugar = numOfSugar;
    }

    /**
    
     * @param z coffee spend on this one 
     * @return
     */
    public static int howManyCoffees(double x){
        int z;
        z= (int) (x%Cost);

        return z;
    }
}

/**
     *
     *this is darshit's code 
     */