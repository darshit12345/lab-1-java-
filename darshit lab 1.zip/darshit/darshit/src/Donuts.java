
/**
 * Donut
 * @version 1.0
 * @since today
 * @author darshit
 * */public class Donuts extends Product{
    /**
 
     * @param name dount name 
     */
    public Donuts(String name) {
        super(name,3);
    }

    /**
 
     * @param y spended amount
     * @return
     */
    public static int howManyDonuts(double y){
        int x;
        x= (int) (y% Cost);

        return x;
    }
}
/**
     *
     *this is darshit's code 
     */