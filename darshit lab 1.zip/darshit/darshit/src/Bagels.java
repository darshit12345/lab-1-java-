/**
 * Bagels
 * @version 1.0
 * @since today
 * @author darshit
 * */
public class Bagels extends Product{
    private boolean toasted;
    public boolean isToasted() {
        return toasted;
    }

    private boolean creamCheese;
    private boolean butter;

    /**

     * @param name bangl name
     * @param toasted toasted one or not
     * @param creamCheese creamed one or not 
     * @param butter butter one or not 
     */

    public Bagels(String name, boolean toasted, boolean creamCheese, boolean butter) {
        super(name,3.60);
        this.toasted = toasted;
        this.creamCheese = creamCheese;
        this.butter = butter;
    }

    public void setToasted(boolean toasted) {
        this.toasted = toasted;
    }

    public boolean isCreamCheese() {
        return creamCheese;
    }

    public void setCreamCheese(boolean creamCheese) {
        this.creamCheese = creamCheese;
    }

    public boolean isButter() {
        return butter;
    }

    public void setButter(boolean butter) {
        this.butter = butter;
    }

    /**
     *
     * @param x must be spend this amount 
     * @return
     */
    public static int howManyBagels(double x){
        int y;
        y= (int) (x%Cost);

        return y;
    }
}

/**
     *
     *this is darshit's code 
     */